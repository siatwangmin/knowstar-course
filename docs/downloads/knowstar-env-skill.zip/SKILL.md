---
name: knowstar-classroom-env
description: 在学员已安装 Docker Desktop 的 Windows 10 电脑上，拉取知错星 V1-V4 统一教学镜像，启动空白项目容器并验收 Web、Android、CloudBase 开发工具。适用于 TraeWork/TraeCode 的课程环境初始化。
---

# 知错星统一教学环境

本 Skill 只安装工具链与生成占位项目。学员没有教师工程；`docs/design/PRD.md`、Gemini Canvas 导出的 HTML 和 V1-V4 业务代码由学员自己完成，不要求 spec。四阶段使用同一个镜像，不在学员机器运行 `npm install`、`npm ci` 或 `docker build`。

## 运行位置与输入

学员应先在 Windows 宿主机自行下载、安装并启动 [Docker Desktop](https://docs.docker.com/desktop/setup/install/windows-install/)。本 Skill 不安装 Docker Desktop、不修改 WSL 或系统设置。

在 Windows 10 的 **TraeWork 桌面版 Code 模式、本地任务**中运行，并用宿主机 PowerShell 执行 Docker 命令。Windows 的 Work/Design 模式使用隔离虚拟环境，不能据其 `docker` 输出判断宿主机已安装；云端任务也不能操作本机 Docker。若无法切换到本地 Code 模式，指导学员在宿主机 PowerShell 执行命令，并读取回传结果。参考 [TraeWork 沙箱说明](https://docs.trae.cn/work_sandbox)。

本课程固定镜像为 `crpi-iqktgpu6dyytuxiu.cn-hangzhou.personal.cr.aliyuncs.com/aipractice/knowstar-classroom@sha256:874c72192fff872157598d86869c56dae38edc406b5705d232271fd998ad3409`，配套 [compose.yaml](assets/compose.yaml) 已写入该引用。该 digest 已在无登录配置的 Docker 客户端完成远端 manifest 读取与拉取验证。无需向学员索要 ACR 凭据。

## 逐步操作

1. 检查 `docker version`、`docker compose version` 和 `docker info`。确认 Docker Desktop 已启动、切换为 Linux containers，`docker info` 有 Server 信息。若没有安装或 Docker Server 未就绪，给学员 [Docker Desktop 官方下载与安装页面](https://docs.docker.com/desktop/setup/install/windows-install/)，让学员完成与所选后端对应的设置和必要的重启，然后重试；默认按用户安装使用 WSL 2，符合条件的全用户安装可使用 Hyper-V。不要在 TraeWork 中代装。
2. 在学员自选的**空目录**建立课程目录，复制 `assets/compose.yaml` 为 `compose.yaml`。执行 `docker pull crpi-iqktgpu6dyytuxiu.cn-hangzhou.personal.cr.aliyuncs.com/aipractice/knowstar-classroom@sha256:874c72192fff872157598d86869c56dae38edc406b5705d232271fd998ad3409`，再用 `docker image inspect` 核对镜像 ID 为 `sha256:80e90904b301d7b1cd19b17da35ec6952ac5280cfae241b1852acaf467a99fd1`，架构为 `linux/amd64`。若学员网络无法拉取，可用课程镜像 tar 执行 `docker load -i <镜像包路径>`，并在课程目录 `.env` 中写 `KNOWSTAR_IMAGE=knowstar-classroom:all-v4`，使用同一份 Compose 配置。
3. 在课程目录启动：`docker compose up -d --wait app`，等待依赖卷复制完成并显示 healthy；只看到 running 还不算就绪。若宿主机 5187 端口已被占用，仅调整 `compose.yaml` 左侧宿主机端口，并按新端口访问。随后执行 `docker compose exec app node --version`、`docker compose exec app npm --version`、`docker compose exec app java -version`、`docker compose exec app npm ls --depth=0 tailwindcss postcss autoprefixer`、`docker compose exec app npm run build`。浏览器打开 `http://localhost:5187/`（若改过端口则使用新端口），确认显示“环境已就绪”。宿主机应新建 `knowstar-learning` 目录，其中有 `package.json`、`package-lock.json`、`tailwind.config.js`、`postcss.config.js`、`src/style.css` 和 `.env.example`，但没有教师业务代码。检查 `src/style.css` 头部的三条 `@tailwind` 指令；占位页尚无工具类，V1 实现后再核对具体工具类是否进入构建 CSS。学员可在宿主机运行 `git init .\knowstar-learning`。首次启动固定镜像后，检查占位页 `src/App.tsx`、`AGENTS.md` 与 `README.md` 是否仍提示学员编写 spec/交接包或使用无登录云端；如有，仅修正这些占位说明为设计阶段只交 `docs/design/PRD.md` 与 Canvas HTML、V2 使用课程演示用户登录，不改动产品业务。随后重新运行 Web 构建并确认占位页显示新提示。
4. 验证同一镜像的 Android 工具链：执行 `docker compose run --rm app knowstar-android-build`，确认 `knowstar-learning\android\app\build\outputs\apk\debug\app-debug.apk` 存在且大小非零；记录 SHA-256。该脚本从镜像内的 Capacitor 生成工程、编译并同步网页，再用预装 Gradle 依赖以 `--offline` 编译 APK；不得在学员电脑运行 `npm install` 或在线下载 Android 包。若要复核完整 Gradle 根任务，执行 `docker compose exec app bash -lc 'cd /workspace/android && ./gradlew clean assembleDebug --offline --no-daemon'`。直接调用 Gradle 不会先同步最新网页，产品交付仍须运行 `knowstar-android-build`。这个 APK 只含占位页，证明编译环境。教师已用同一镜像编译实际 V3 产品 APK，并确认 APK 验证通过；学员的产品功能仍需在完成 V3 开发后验收。
5. 在环境阶段提醒学员准备自己的服务配置：按 [CloudBase 官方 Skill 接入说明](https://docs.cloudbase.net/skill.md)让 Trae 接入学员自己开通的环境，只读验证 EnvId、PostgreSQL 类型和浏览器 Publishable Key；课程演示用户的密码由学员在控制台设置并保管。提醒学员用自己的硅基流动账号创建 API Key，自行安全保存；此时云函数尚未建立，V4 才由学员在 CloudBase 云函数控制台填写服务端变量 `SILICONFLOW_API_KEY`。只报告每项“已准备/待准备”和填写位置，不索取、读取、打印或写入 Key/密码。EnvId 与 Publishable Key 可在 V2 写入学员工程被 Git 忽略的 `.env.local`，管理密钥与硅基流动 Key 不得进入 `VITE_*`、`.env.example`、镜像、APK、资料包或聊天。云账号和模型额度不由 Docker 镜像提供。

## 验收报告

逐项给出实际命令结果：Windows 与所选 Docker 后端适配、Docker Server/Compose、镜像引用和 digest、Node/npm/JDK、Tailwind 3/PostCSS/Autoprefixer 本地安装与配置、Web 构建、页面访问、APK 路径与 SHA-256、CloudBase 只读连通状态、个人 CloudBase 与硅基流动配置准备状态。只报告配置状态，不输出凭据值。每项标记通过/失败/未验证；失败时给出可重试步骤，不把未执行项目写成通过。任何新增依赖应由教师更新锁文件并重发镜像，学员不自行安装不同版本。
