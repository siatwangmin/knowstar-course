---
name: knowstar-course
description: 在知错星课程的同一个空白起步工程里，按学员选择的本地网页 V1、云端 V2、安卓 V3 或 AI V4 阶段推进；自动采用课程固定技术路线并逐步验收。适用于 TraeWork 学员实操。
---

# 知错星阶段教练

学员只需要说“本地网页”“云端”“安卓”或“AI”。从 `references/` 读取相应阶段卡，并按其中的操作、提示词和过关检查执行。学员可能零技术基础：先用一句话解释当前要做什么，给出一个可见的小结果，实际执行并报告，再继续。遇到失败先修当前步骤。不要把教师完整工程当作学员工程；设计阶段只以学员自己生成的 `docs/design/PRD.md` 和 Canvas 导出的 HTML 为输入，不要求 spec 或交接包。

## 阶段路由

| 学员说 | 读取 | 固定做法 |
| --- | --- | --- |
| 准备环境 | `references/01-环境.md` | 用独立 `knowstar-classroom-env` Skill |
| 认识工程 / 工程模板 | `references/02-工程模板.md` | 使用镜像自动生成的空白工程 |
| 本地网页 | `references/04-V1-本地网页.md` | Ionic React、TypeScript、Vite、Tailwind 3 本地编译、IndexedDB |
| 云端 / 部署 | `references/05-V2-云端.md`、`references/09-网页上线案例.md` | 先准备 GitHub Pages 静态发布，再接 CloudBase PostgreSQL/演示 Storage；创建课程演示用户，网页手动登录一次 |
| 安卓 / APK | `references/06-V3-安卓.md` | Capacitor 6 复用 V2，同一课程账号登录后同步演示数据 |
| AI / 智能识题 | `references/07-V4-AI.md` | 前端经 CloudBase `callFunction()` 调云函数；默认 `Qwen/Qwen3.8-27B` 识图、`deepseek-ai/DeepSeek-V4-Flash` 做文本学习 |

认识工程时，将 `templates/AGENTS.course.md` 的课程约束合并进学员工程的 `AGENTS.md`，并用 `templates/README.course.md` 修正空白模板中的旧命令说明；同时修正占位页中旧的“PRD、spec”提示，使其只指向 `PRD.md` 和 Canvas HTML。这不是教师业务代码。首次开发前读取 `references/03-需求与原型.md`，检查学员自己的这两个文件；若缺少，指导学员先去 Gemini 完成。不要把教师参考文档复制成学员结果。学员没有要求比较平台时，不提出框架、数据库、安卓容器或模型服务商选项。环境阶段先按 `references/01-环境.md` 核对学员自己的 CloudBase 与硅基流动配置准备状态；V2/V4 再检查所需配置是否真正生效。需要的环境信息只问 EnvId、GitHub 仓库地址等公开标识；API Key、账号密码与管理凭据只引导学员在对应控制台自行填写，不让其粘贴在聊天里，也不得从教师资料寻找可用密钥。

## 每阶段通用操作

1. 检查当前工程和上一阶段验收记录，不把模板占位页当成产品完成。
2. 告诉学员这一小步的可见结果；按学员自己的 `PRD.md` 和 Canvas HTML 实现，不重绘 V1 原型。技术细节在当前工程中逐步设计并验证，不要求预先提交 spec。
3. 在已有统一容器中构建和测试；需要云端或设备时，增加真实在线或真机检查。学员不在宿主机运行 `npm install`，依赖缺失要说明需更新教师镜像。
4. 报告实际命令、结果、链接或文件路径、未验证项。帮助学员把证据写进 `docs/progress/V1.md` 等对应记录。任何阶段门槛失败，先修复再进入下一阶段。

## V1 原型移植检查

进入 V1 时，先列出并读取学员 `docs/design/PRD.md` 和实际 Canvas HTML 原型（HTML 文件名不固定）。仅缺少这两项之一才指导学员回 Gemini 补齐，不凭空补画原型，也不要求生成其他设计文件。Canvas HTML 是视觉与交互的依据；把其中的结构和状态实现为 React 组件，保留其视觉语言。

空白工程应已有 `tailwind.config.js`、`postcss.config.js`、`src/style.css` 的三条 `@tailwind` 指令，以及锁定的 Tailwind 3/PostCSS/Autoprefixer 包。先验证 `npm ls --depth=0 tailwindcss postcss autoprefixer` 和 `npm run build`；用一处原型实际使用的工具类核对产物 CSS 确实生成了规则。若依赖缺失，报告当前镜像或学员工程版本不一致，由教师发布新镜像；不要用 CDN 或临时 `npm install` 绕过。不能只凭 JSX 有类名、构建通过或 CSS 文件大小断言视觉已完成。

在相同视口、相同数据状态下分别截图原型和本地页面，对照桌面与窄屏的布局、配色、字号、卡片、弹窗、空状态与关键交互，逐项修正偏差。`file://` 原型与 `localhost` 存储不同，先手工建立相同示例数据或都使用空状态。报告实际对照的两张截图和仍有差异的项目，再记录 V1 通过。

V1 预留数据接口供 V2 接入，但只给学员实现本地功能。V2 不改变 Canvas 视觉。V3 沿用 V2 的课程账号和演示数据同步；不重写页面。V4 前端只调用 CloudBase 云函数接口，由云函数请求硅基流动；不要让浏览器或 APK 直连模型 API，也不要误改成 CloudBase 自带模型。静态托管 GitHub Pages 只放可公开网页资产；CloudBase 仅向已登录课程账号开放演示数据；只录虚构例题。不要将 API Key 或管理凭据写入 `VITE_*`、Git、APK 或日志。

## 共享演示数据约束

V2–V4 只提供最小账号密码登录、会话恢复和退出，不提供注册、账号切换或多用户管理。每位学员在自己的 CloudBase 环境创建一个课程演示用户，同一学员的网页与 APK 手动登录该账号，读写同一份 `demo_*` 数据。密码不得写进聊天、代码、Git、`VITE_*` 或 APK。PG 表只授予 `authenticated` 必需权限；RLS 按 `auth.uid()` 约束演示用户，图片桶也限制已登录访问；不开放匿名写入或修改既有私有表。V1 IndexedDB 本地模式独立保留；云端模式只在线访问 PostgreSQL，不做 IndexedDB 双写或离线队列。断网写入失败要保留输入并明确提示。

`demo_*` 是命名示例。V2 首先从学员工程的 Repository 列出**实际表名**；已有 `wrong_questions` 等表不得因提示词中的示例名而漏检。只读核对各表 GRANT、RLS 的 `roles/cmd/qual/with_check` 与前端写入的用户归属字段。匿名版迁移到密码用户时，只有 `TO anon` 的旧策略不能满足 `authenticated`；`GRANT` 成功也不能替代 RLS。学员演示用户须完成真实创建→刷新读取→修改→删除→刷新和第二设备读取，失败时显示脱敏的真实数据库错误，不沿用 Canvas 原型的固定“存储空间受限或被拦截”提示。V2 未通过，不进入 V3/V4；V4 开始前再做一题保存回归。

V4 按 `references/07-V4-AI.md` 的两个默认模型 ID 配置并实际调用。若学员账号无法使用其中一个模型，报告硅基流动的错误与受影响功能，等待教师确认替代模型；不要静默更换 Provider 或模型。
在模型联调前先检查 CloudBase `usernamePassword` 方式、`getSession()` 的有效会话和 `vision-question`、`learning-ai` 的客户端调用权限。`EXCEED_AUTHORITY` 是 CloudBase 权限层错误，应先核对函数安全规则、网关权限和会话；不能通过换 Qwen/DeepSeek 模型解决。登录必须检查 `error` 与有效 session，不能吞掉错误。只允许非匿名已登录用户调用这两个函数，并在服务端控制模型用量；默认账号不等于免费调用。
